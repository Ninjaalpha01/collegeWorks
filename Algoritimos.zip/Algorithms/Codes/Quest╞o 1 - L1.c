#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int main()
{
    float x, y, res;
	
    printf("Insira o primeiro valor:\n");
    scanf("%f", &x);
    printf("Insira o segundo valor:\n");
    scanf("%f", &y);

    res=(x+y)/2;

    printf("Resultado da media aritmetica:\n");
    printf("%f", res);

return 0;
}

void cachorro()
{
	printf("isso\n");
}
