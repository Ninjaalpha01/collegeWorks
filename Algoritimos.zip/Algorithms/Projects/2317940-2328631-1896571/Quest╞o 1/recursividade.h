int multiplicacao(int a, int b);
void decrescente(int n);
void impares(int n);
unsigned int pares(int n, int aux);
int palindromo(char p[], int tam, int pos);
int somanaturais(int a, int b);
int devolveindice(int v[], int k, int n);