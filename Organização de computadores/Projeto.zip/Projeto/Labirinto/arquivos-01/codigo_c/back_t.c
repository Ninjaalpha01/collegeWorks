#include <stdio.h>
#include <stdlib.h>

int *mat;
int t_linhas, t_colnas;
int linha_entrada, coluna_entrada;

int acessa_mat(int l, int c){
	return (mat[l*t_linhas + c]);
}

void escreve_mat(int l, int c, int valor){
	mat[l*t_linhas + c] = valor;
}

#define parede 	0
#define caminho_livre 255
#define pintura	50
int caminho_lab(int y, int x){
	/* tenta ir para cima.
	*  Se tem caminho: 	pinta e segue para cima
	*  SE tem parede:	tenta para esquerda
						tenta para baixo
						tenta para direita
	*/

	int achou =0;	

	// se achou uma borda está na saida:
	if ( (y+1 == t_colnas) || (x+1 == t_linhas) || (x == 0) || (y == 0) )
		if (acessa_mat(y,x)==caminho_livre)
			achou = 1;

	// pinta na chegada:
	escreve_mat(y,x, pintura);
	
	// tenta para cima
	if ( !achou && (y-1 >= 0) && (acessa_mat(y-1,x) == caminho_livre) ) 
		achou = caminho_lab(y-1,x);

	// tenta para esquerda
	if ( !achou && (x-1 >= 0) && (acessa_mat(y,x-1) == caminho_livre) ) 
		achou = caminho_lab(y,x-1);
	
	// tenta para baixo
	if( !achou && (x+1 < t_linhas) && (acessa_mat(y+1,x) == caminho_livre) )
		achou = caminho_lab(y+1,x);
		
	// tenta para direita
	if ( !achou && (y+1 < t_colnas) && (acessa_mat(y,x+1) == caminho_livre) )
		achou = caminho_lab(y,x+1);

	// verifica se achou:
	if (achou) return achou;
	
	/* terminou os testes.
	*  achou saida?
	*    sim: termina sem apagar
	*    não: apaga e volta
	*/


	else // apaga
		escreve_mat(y,x,caminho_livre);

	return 0;
	
}

FILE *f_in, *f_out;
#include <string.h>
void leitura_cabecalho(FILE* fi){
	char str[256]="";
	int aux;

	fscanf(fi,"%s\n",str);
	fscanf(fi,"%c %d %d ", str, &coluna_entrada, &linha_entrada);
	fgets(str,256,fi);
	printf("%s", str);
	fscanf(fi,"%d %d\n", &t_linhas, &t_colnas);
	fscanf(fi,"%d\n",&aux);

}
void escrita_cabecalho(FILE* fo){
	char str[256]="";
	int aux;

	fprintf(fo,"P2\n");
	fprintf(fo,"# %d %d %s\n", coluna_entrada, linha_entrada, "criado por mim mesmo...");
	fprintf(fo,"%d %d\n", t_linhas, t_colnas);
	fprintf(fo,"255\n");
}

void leitura_mat(FILE* fi){
	int aux;

	if ( NULL == (mat= (int* ) malloc(t_linhas*t_colnas*sizeof(int)))){
		puts("erro de alocação da matriz");
		exit(0);
	}

	for(aux=0;aux<t_linhas*t_colnas;aux++)
		fscanf(fi,"%d",&mat[aux]);
}

void salva_mat(FILE* fo){
	int aux;

	 for(aux=0;aux<t_colnas*t_linhas;aux++)
	 	fprintf(fo,"%d\n",mat[aux]);

	 // usado para corrigir os labirintos com contarnos brancos
	 // isso atrapalho bastante!
	 //
	 // for (int i = 1; i < t_colnas-1; ++i)
	 // {
	 // 	for (int j = 1; j < t_linhas-1; ++j)
	 // 	{
	 // 		fprintf(fo,"%d\n",mat[i*(t_linhas)+j]);
	 // 	}
	 // }
}

void main(){
	char arquivo[256];

	printf("Qual o nome do arquivo de entrada?\n");
	scanf ("%s",arquivo);

	f_in=fopen(arquivo,"r");
	
	arquivo[strlen(arquivo)-4]='\0';
	f_out=fopen(strcat(arquivo,"-saida.pgm"),"w");

	leitura_cabecalho(f_in);
	escrita_cabecalho(f_out);
	leitura_mat(f_in);
	escreve_mat(linha_entrada,coluna_entrada, pintura);
	caminho_lab(linha_entrada,coluna_entrada);

	salva_mat(f_out);

	fclose(f_in);
	fclose(f_out);
}
