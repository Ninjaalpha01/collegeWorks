int MMC(int n1, int n2, int n3);
int MDC(int n1, int n2, int n3);
int fat(int x);
int maiorvet(int vet[], int tamanho, int term1);
int somavet(int vet[], int tam);
int *alocaveti(int tam);
int *concatint(int *a, int na, int *b, int nb);

void inverte(char str[], int tamanho);
void cesar(char str[]);
void imprimeint(int *vet, int tam);
void imprimechr(char *vet);
void desalocai(int **vet);
void desalocac(char **vet);
void desalocaf(float **vet);
void armint(int *vet, int tam);

float *concaflo(float *v1, float *v2, int n1, int n2);

double multvet(int vet[], int tam);

int reset();
