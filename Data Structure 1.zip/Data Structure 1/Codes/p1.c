#include <stdio.h>

int main()
{
	int *p=NULL;
	
	scanf("%d", p);
	printf("%d", p);
	
	return 0;
}
